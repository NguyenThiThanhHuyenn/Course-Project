package com.example.apiroy.Enum;

public enum BookStatus {
    PENDING, // Đang chờ duyệt
    APPROVED, // Đã được duyệt
    REJECTED // Bị từ chối
}
