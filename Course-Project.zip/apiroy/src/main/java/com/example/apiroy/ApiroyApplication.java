package com.example.apiroy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiroyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiroyApplication.class, args);
	}

}