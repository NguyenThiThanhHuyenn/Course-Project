import React from "react";

function AudioForm() {
  // Mã của giao diện đăng audiobook
  return (
    <div>
      {/* Nội dung form audiobook */}
    </div>
  );
}

export default AudioForm;
