package com.example.apiroy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiroyApplicationTests {

	@Test
	void contextLoads() {
	}

}
