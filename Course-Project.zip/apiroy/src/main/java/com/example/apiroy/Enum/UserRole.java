package com.example.apiroy.Enum;

public enum UserRole {
    ROLE_USER, // Vai trò người dùng thông thường
    ROLE_ADMIN // Vai trò quản trị viên
}
